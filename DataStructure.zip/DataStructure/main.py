import time
import datetime

# Using lists inside a dictionary
patient = {
    "Patient ID": [],
    "Full Name": [],
    "Date Of Birth(mm/dd/yyyy)": [],
    "Appointment": [],
}


def isTimeFormat(input):
    try:
        time.strptime(input, '%H:%M')
        return True
    except ValueError:
        print("Incorrect Time!")


def dobFormat(dob):
    try:
        datetime.datetime.strptime(dob, "%d/%m/%Y")
        return True
    except ValueError:
        print("Incorrect Birthdate!")


# Adding patient details to dictionary
def TakeAppointment():
    id = int(input("Enter patient ID: "))
    name = input("Enter patient name: ")
    dob = input("Enter Patient Date Of Birth(mm/dd/yyyy): ")
    time = input("Enter patient appointment time(hh:mm): ")

    if isTimeFormat(time) and dobFormat(dob) is True:
        patient["Patient ID"].append(id)
        patient["Full Name"].append(name)
        patient["Date Of Birth(mm/dd/yyyy)"].append(dob)
        patient["Appointment"].append(time)


print("************************************")
print("|\t Patient Appointment System    |")
User_Choice = True

while User_Choice:
    print("************************************")
    print("Choose an option from below:"
          "\n1. Take an appointment"
          "\n2. Cancel an appointment"
          "\n3. Edit an appointment"
          "\n4. Find a patient"
          "\n5. View all the appointments"
          "\n6. Exit")
    print("************************************")

    User_Choice = int(input("What would you like to do? "))
    if User_Choice == 1:
        print(TakeAppointment())

    elif User_Choice == 2:
        id = int(input("Enter patient ID to cancel appointment: "))
        index = 0
        for i in range(len(patient["Patient ID"])):
            if patient["Patient ID"][i] == id:
                index = i
                del patient["Patient ID"][index]
                del patient["Full Name"][index]
                del patient["Date Of Birth(mm/dd/yyyy)"][index]
                del patient["Appointment"][index]
                print("The patient's appointment is cancelled!!")

    elif User_Choice == 3:
        id = int(input("Enter patient ID to edit appointment: "))
        index = 0
        for i in range(len(patient["Patient ID"])):
            if patient["Patient ID"][i] == id:
                index = i
                name = input("Enter the Full Name: ")
                dob = input("Enter the Date Of Birth(mm/dd/yyyy): ")
                appt = input("Enter the Appointment time: ")
                patient["Full Name"][index] = name
                patient["Date Of Birth(mm/dd/yyyy)"][index] = dob
                patient["Appointment"][index] = appt
                print("The patient's appointment is updated!!")

    elif User_Choice == 4:
        id = int(input("Enter patient ID: "))
        index = 0
        for i in range(len(patient["Patient ID"])):
            if patient["Patient ID"][i] == id:
                index = i
                print("Full Name:", patient["Full Name"][index])
                print("Date Of Birth(mm/dd/yyyy):", patient["Date Of Birth(mm/dd/yyyy)"][index])
                print("Appointment:", patient["Appointment"][index])
            else:
                print("Patient does not exist!")

    elif User_Choice == 5:
        print("Patient ID:", patient["Patient ID"])
        print("Full Name:", patient["Full Name"])
        print("Date Of Birth(mm/dd/yyyy):", patient["Date Of Birth(mm/dd/yyyy)"])
        print("Appointment:", patient["Appointment"])

    elif User_Choice == 6:
        exit()
